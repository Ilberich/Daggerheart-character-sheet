---
name: daggerheart-srd
description: Use when answering questions about Daggerheart TTRPG rules, mechanics, character creation, classes, ancestries, combat, equipment, or GM guidance from the official SRD v1.0
---

# Daggerheart SRD 9-09-25 — Rules Reference Skill

Daggerheart is a collaborative fantasy tabletop roleplaying game (TTRPG) by Darrington Press / Critical Role. This skill covers the **System Reference Document (SRD) v1.0**, the official mechanics reference for the game.

> Source: Daggerheart SRD 1.0, © 2025 Critical Role LLC. Public Game Content under the Darrington Press Community Gaming License.

---

## 💡 When to Use This Skill

Use this skill when the user asks about:

- **Core rules** — how action rolls, Duality Dice, Hope/Fear tokens, and Difficulty work
- **Character creation** — classes, subclasses, domains, ancestries, communities, traits
- **Combat mechanics** — turn order, attacking, stress, damage, range, conditions
- **Equipment** — weapons, armor, loot, consumables, weapon traits
- **Progression** — leveling up, multiclassing, experience
- **GM mechanics** — adversaries, environments, spotlight, action economy, fear moves
- **Downtime & death** — downtime activities, death moves, the Work on a Project move
- **The Witherwild Campaign Frame** — included campaign setting material
- **Homebrew creation** — verifying mechanics conform to Daggerheart's core ruleset
- **SRD licensing** — understanding what is Public Game Content under the Community Gaming License

**Do NOT use this skill for:**
- Flavor, lore, or narrative content from the full core rulebook (not in the SRD)
- Artwork, setting fiction, or personal advice on how to roleplay

---

## ⚡ Quick Reference — Core Mechanics

### Duality Dice & Action Rolls

When a player makes an **action roll**:
1. Roll two differently-colored d12s (the **Duality Dice**) — one represents **Hope**, one represents **Fear**
2. Add the relevant **trait modifier** to the result
3. Compare the total to a **Difficulty** set by the GM
   - **Meet or beat** → Success
   - **Below** → Failure
4. Check which Duality Die rolled higher:
   - **Hope die higher** → Player gains a **Hope token**
   - **Fear die higher** → GM gains a **Fear token**

### Hope & Fear Tokens

| Token | Who holds it | Primary use |
|-------|-------------|-------------|
| Hope  | Players     | Spend to activate abilities, boost rolls, or use class features |
| Fear  | GM          | Spend to trigger adversary abilities, create complications, or use GM moves |

### The Six Traits

Characters have six traits used as modifiers on action rolls:

- **Agility** — speed, stealth, reflexes
- **Strength** — power, athletics, brute force
- **Finesse** — precision, dexterity, sleight of hand
- **Instinct** — perception, survival, gut feelings
- **Presence** — charisma, leadership, performance
- **Knowledge** — lore, magic theory, investigation

### Difficulty Thresholds

The GM sets a Difficulty for action rolls. The SRD does not prescribe fixed numbers — the GM uses narrative judgment. Common benchmarks:

- **Easy task**: ~8–10
- **Moderate task**: ~12–15
- **Hard task**: ~17–20
- **Near-impossible**: 20+

---

## 📖 Document Structure (68 pages)

| Section | Pages | Contents |
|---------|-------|----------|
| Introduction | 1–3 | What Is This, The Basics, Golden Rule |
| Character Creation | 4–6 | Step-by-step character building |
| Core Materials | 7–34 | Domains, Classes (8+), Ancestries, Communities |
| Core Mechanics | 35–62 | Flow of Play, Combat, Stress, Death, Leveling, Equipment |
| Running an Adventure | 63–118 | GM Guidance, Adversaries, Environments, Witherwild Frame |
| Appendix | 119+ | Domain Card Reference |

---

## 🧩 Key Concepts

### Classes & Domains

- Characters belong to a **class** (e.g., Bard, Druid, Guardian, Ranger, Rogue, Seraph, Sorcerer, Warrior, Wizard)
- Each class draws from one or more **Domains** (thematic pools of abilities)
- Domains include: Arcana, Blade, Bone, Codex, Grace, Midnight, Sage, Splendor, Valor, etc.
- At character creation, players choose a **subclass**, which determines their **Spellcast trait** (if applicable) and signature abilities

### Ancestries & Communities

- **Ancestry** describes biological or cultural heritage (physical traits, innate abilities)
- **Community** describes the social environment a character grew up in (background-style bonuses)
- These are separate choices and both contribute to starting features

### Stress

- Characters track **Stress** — a resource representing mental/physical strain
- Taking certain actions, failing rolls, or narrative consequences can add Stress
- When Stress fills up, characters face increasingly serious consequences

### Combat Flow

1. **Spotlight** — the GM determines who acts when via narrative spotlight, not strict initiative
2. On their turn a player can **make a move** (action), **attack**, **use an ability**, or **take another action** as allowed
3. **Attacking**: Roll with a relevant trait + weapon bonus vs. the target's **Difficulty** (set by their stat block or GM ruling)
4. **Range bands**: Close, Near, Far (narrative distance categories, not grid squares)

### Conditions

Conditions are temporary states (e.g., Restrained, Frightened, Vulnerable) applied by abilities or GM moves. Each has a defined mechanical effect listed in the SRD.

### Death

When a character would die, they make a **death move** — a special roll that gives the player agency over their character's final moments. Instant narrative death (e.g., diving into a volcano) can bypass this, but the GM should warn the player before it happens.

### Leveling Up

Characters level up by **gaining experience** through play. Each level unlocks new class features, higher trait scores, additional domain cards, and increased Stress capacity. Multiclassing is supported and follows rules in the SRD (pp. 43–44).

### Equipment

- **Weapons** have traits (e.g., *Reach*, *Thrown*, *Two-Handed*), a primary trait used to attack, and a damage die
- **Armor** provides **Armor Slots** — each slot can absorb one hit; slots recharge on rest
- Some armor grants bonus modifiers (e.g., "+10 to a stat")
- **Consumables** are single-use items (potions, scrolls, etc.)
- **Loot** is treasure found during play, convertible to gear or gold

### GM Mechanics

- The GM uses **Fear tokens** to take **GM moves** — narrative complications, adversary actions, or scene escalations
- **Adversaries** have stat blocks with a **Difficulty**, **HP**, attack traits, and special moves
- Adversary stat blocks are re-usable: any number of in-fiction creatures can share one stat block

---

## 🗂️ Reference Files

| File | Contents | Confidence |
|------|----------|------------|
| `references/Daggerheart-SRD-9-09-25.md` | Full SRD text, pages 1–68, extracted from PDF | Medium — PDF extraction; some special characters (fi, ff ligatures) may be malformed |
| `references/index.md` | Index of reference files and statistics | Medium |

**Note on confidence:** The reference files are PDF-extracted text. Special characters like *fi* in "specified" or *ff* in "different" may appear as `ﬁ` or `ﬀ` due to PDF ligature encoding. The mechanical content is reliable; formatting artifacts are cosmetic only.

---

## 🧭 Working With This Skill

### For beginners (new to Daggerheart)
1. Start with **Introduction → The Basics** (pp. 1–3) for the core loop
2. Read **Character Creation** (pp. 4–6) to understand character building
3. Use the **Quick Reference** section above as a cheat sheet during play

### For intermediate users (familiar with the game)
- Jump to specific sections by topic using the Document Structure table above
- Check `references/Daggerheart-SRD-9-09-25.md` for exact rule text when rulings matter
- The **Appendix → Domain Card Reference** (p. 119+) is useful for ability lookup

### For advanced users (homebrewers, publishers)
- The SRD is licensed under the **Darrington Press Community Gaming License** — review p. 1 and visit `www.darringtonpress.com/license` before publishing
- The SRD intentionally omits flavor/lore; it is the mechanical skeleton only
- Adversary stat blocks are designed for re-use — one block can represent many narrative creatures

### Golden Rule (directly from the SRD)
> "The most important rule of Daggerheart is to make the game your own. The rules should never get in the way of the story you want to tell... As long as your group agrees, everything can be adjusted to fit your play style."

### Rulings Over Rules
> "When you're in doubt about how a rule applies, the GM should make a ruling that aligns with the narrative."

---

## 📊 Source Statistics

- **Source**: Daggerheart SRD 1.0 PDF (September 2025 release)
- **Pages**: 68
- **Extraction confidence**: Medium (PDF text extraction with ligature artifacts)
- **Conflicts detected**: None (single-source document)
- **License**: Public Game Content — Darrington Press Community Gaming License

---

*Reference: `references/Daggerheart-SRD-9-09-25.md` | See `references/index.md` for full structure.*
